﻿/* Copyright 2010-present MongoDB Inc.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

using System;

namespace MongoDB.Bson.IO
{
    /// <summary>
    /// Represents the output mode of a JsonWriter.
    /// </summary>
    public enum JsonOutputMode
    {
        /// <summary>
        /// Output strict JSON (an obsolete output mode that is similar to canonical extended JSON).
        /// </summary>
        [Obsolete("Use CanonicalExtendedJson instead.")]
        Strict,

        /// <summary>
        /// Use a format that can be pasted in to the MongoDB shell.
        /// </summary>
        Shell,

        /// <summary>
        /// Output canonical extended JSON.
        /// </summary>
        CanonicalExtendedJson,

        /// <summary>
        /// Output relaxed extended JSON.
        /// </summary>
        RelaxedExtendedJson,

        /// <summary>
        /// Use JavaScript data types for some values.
        /// </summary>
        [Obsolete("Use Shell instead.")]
        JavaScript = Shell,

        /// <summary>
        /// Use JavaScript and MongoDB data types for some values.
        /// </summary>
        [Obsolete("Use Shell instead.")]
        TenGen = Shell
    }
}
