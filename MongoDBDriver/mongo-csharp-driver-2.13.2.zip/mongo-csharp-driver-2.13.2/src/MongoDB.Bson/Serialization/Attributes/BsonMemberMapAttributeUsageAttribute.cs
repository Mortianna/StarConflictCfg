﻿/* Copyright 2010-present MongoDB Inc.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

using System;

namespace MongoDB.Bson.Serialization
{
    /// <summary>
    /// Indicates the usage restrictions for the attribute.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    public class BsonMemberMapAttributeUsageAttribute : Attribute
    {
        // private fields
        private bool _allowMultipleMembers;

        // constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="BsonMemberMapAttributeUsageAttribute" /> class.
        /// </summary>
        public BsonMemberMapAttributeUsageAttribute()
        {
            _allowMultipleMembers = true;
        }

        // public properties
        /// <summary>
        /// Gets or sets a value indicating whether the attribute this attribute applies to is allowed to be applied
        /// to more than one member.
        /// </summary>
        public bool AllowMultipleMembers
        {
            get { return _allowMultipleMembers; }
            set { _allowMultipleMembers = value; }
        }
    }
}
